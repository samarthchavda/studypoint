const Category = require("../models/Category");

// Seed 5 most popular categories for StudyNotion platform
const categories = [
  {
    name: "Web Development",
    description: "Learn to build modern websites and web applications using HTML, CSS, JavaScript, React, Node.js and more",
  },
  {
    name: "Data Science",
    description: "Explore data analysis, machine learning, AI, and big data technologies",
  },
  {
    name: "Mobile Development",
    description: "Master mobile app development with Android, iOS, React Native, and Flutter",
  },
  {
    name: "Programming Languages",
    description: "Learn programming fundamentals with Python, Java, C++, JavaScript and other languages",
  },
  {
    name: "UI/UX Design",
    description: "Master user interface and user experience design with Figma, Adobe XD, and design principles",
  },
];

const seedDatabase = async () => {
  try {
    console.log("Starting database seeding...");

    // Check if categories already exist
    const existingCategories = await Category.countDocuments();
    
    if (existingCategories > 0) {
      console.log(`Found ${existingCategories} existing categories`);
      console.log("Skipping seeding to avoid duplicates");
      console.log("To reseed, please delete existing categories first");
      return;
    }

    // Insert categories
    const result = await Category.insertMany(categories);
    console.log(`✅ Successfully seeded ${result.length} categories`);
    
    // Display seeded categories
    result.forEach((category, index) => {
      console.log(`${index + 1}. ${category.name}`);
    });

  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
};

module.exports = seedDatabase;
