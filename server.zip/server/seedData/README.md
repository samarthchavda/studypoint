# Database Seeder

This directory contains database seeding scripts for initializing the StudyNotion database with default data.

## Categories Included

The seeder automatically populates 15 categories:

1. **Web Development** - HTML, CSS, JavaScript, React, Node.js
2. **Mobile Development** - Android, iOS, React Native, Flutter
3. **Data Science** - Data Analysis, Machine Learning, AI
4. **Programming Languages** - Python, Java, C++, JavaScript
5. **Database Management** - SQL, NoSQL, MongoDB, PostgreSQL
6. **Cloud Computing** - AWS, Azure, Google Cloud
7. **DevOps** - CI/CD, Docker, Kubernetes, Jenkins
8. **Cybersecurity** - Ethical Hacking, Network Security
9. **UI/UX Design** - Figma, Adobe XD, Design Principles
10. **Digital Marketing** - SEO, Social Media, Content Marketing
11. **Business & Management** - Leadership, Project Management
12. **Artificial Intelligence** - Neural Networks, Deep Learning
13. **Blockchain** - Cryptocurrency, Smart Contracts, Web3
14. **Game Development** - Unity, Unreal Engine
15. **Photography & Video** - Photography, Videography, Video Editing

## How to Run

### Option 1: Using npm script (from server directory)
```bash
cd server
npm run seed
```

### Option 2: Direct execution
```bash
cd server
node scripts/runSeeder.js
```

## Important Notes

- The seeder will **skip** if categories already exist to avoid duplicates
- To reseed, first delete existing categories from the database
- Make sure your `.env` file is properly configured with `MONGO_URI`
- The server must be able to connect to MongoDB

## Clearing Data

If you want to reseed, connect to MongoDB and run:
```javascript
db.categories.deleteMany({})
```

Or use MongoDB Compass/Atlas to delete all categories manually.
